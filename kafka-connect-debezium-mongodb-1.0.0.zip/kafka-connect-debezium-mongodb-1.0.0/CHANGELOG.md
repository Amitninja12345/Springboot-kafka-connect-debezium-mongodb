# Changelog

## [1.0.0] - 2023-11-08
### Added
- Initial project
